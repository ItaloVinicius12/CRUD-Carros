import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class ConnectionFactory {
	
public static Connection getConnection() {
		
		
		try {        
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			
			
			//pegando o caminho do meu banco de dados
			return (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Carros", "root","");
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	

}
