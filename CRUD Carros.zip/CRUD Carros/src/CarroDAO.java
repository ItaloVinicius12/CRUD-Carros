import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

import javax.swing.JOptionPane;


public class CarroDAO implements InterfaceBancoDAO{

	
	
	//--------------- Inserir- ---------------

	@Override          //objeto que eu vou inserir
	public void Inserir(Carro c) {
		
		String sql=("insert into carro(marca,modelo,cor,placa) values(?,?,?,?)");
		
		try(Connection con= new ConnectionFactory().getConnection()){
			
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, c.getMarca());
			ps.setString(2, c.getModelo());
			ps.setString(3, c.getCor());
			ps.setString(4, c.getPlaca());
			
			ps.execute();//executando a instru��o SQL
			JOptionPane.showMessageDialog(null, "Dados salvos com sucesso !");
			
		    ps.close();//fechando a conex�o
			
		}catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao salvar:"+e, "ERROR", JOptionPane.ERROR_MESSAGE);
			
			throw new RuntimeException(e);
		}
		
	}
	
	
	
	//------------ Alterar -----------------
	@Override
	public void alterar(Carro c) {
		
		String sql="update carro set marca=?, modelo=?,cor=?,placa=? where id=?";
		
		try(Connection con= new ConnectionFactory().getConnection()){
			
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setString(1, c.getMarca());
			ps.setString(2, c.getModelo());
			ps.setString(3, c.getCor());
			ps.setString(4, c.getPlaca());
			ps.setInt(5, c.getId());
			
			ps.executeUpdate();
			JOptionPane.showMessageDialog(null, "Alterado com sucesso ! ");
			
			ps.close();
		
			
		}catch(SQLException e) {
			
			JOptionPane.showMessageDialog(null, "Erro ao alterar:"+e, "ERROR", JOptionPane.ERROR_MESSAGE);
			
			throw new RuntimeException(e);
		}
		
		
	}
	
	

	
	//------------ Listar-----------------
	
	@Override
	public ArrayList<Carro> listar() {
		
		ArrayList<Carro> carros= new ArrayList<>();
		String sql="select * from carro";
		
	try(Connection con= new ConnectionFactory().getConnection()){
		
		PreparedStatement ps= con.prepareStatement(sql);
		
		/*ResultSet � uma interface utilizada pra guardar dados vindos de um banco de dados,
		 *ela guarda o resultado de uma pesquisa numa estrutura de dados que pode ser percorrida,
		 *de forma que voc� possa ler os dados do banco.*/
		
		ResultSet rs=ps.executeQuery();//guarando a PreparedStatament dentro da resultSet
		
		
		//vai percorrer a tabela
		while(rs.next()) {
			
			Carro c= new Carro();
			
			//pegando os dados da tabela
			c.setId(rs.getInt(1));
			c.setMarca(rs.getString(2));
			c.setModelo(rs.getString(3));
			c.setCor(rs.getString(4));
			c.setPlaca(rs.getString(5));
			
			//armazenando os valores do banco dentro do Arraylist de Carro
			carros.add(c);
		}	
		
		ps.close();
		rs.close();
		
	}catch(SQLException e){
		
		JOptionPane.showMessageDialog(null, "Erro ao realziar consulta:"+e, "ERROR", JOptionPane.ERROR_MESSAGE);
		throw new RuntimeException(e);
		
	}
		

		return carros;
	}

	
	
	
	
	//------------ Remover-----------------
	@Override
	public void remover(Carro c) {
		
		String sql="delete from carro where id=?";
		
		try(Connection con= new ConnectionFactory().getConnection()) {
			
			PreparedStatement ps= con.prepareStatement(sql);
			
			ps.setInt(1, c.getId());
			
		    ps.execute();
			
			JOptionPane.showMessageDialog(null, "Removido com sucesso !");
			
			ps.close();
			
			
		}catch(SQLException e) {
			
			
			JOptionPane.showConfirmDialog(null, "Erro ao remover:"+e, "Error", JOptionPane.ERROR_MESSAGE);
			
			throw new RuntimeException(e);
		}
		
		
	}

	
	
}
