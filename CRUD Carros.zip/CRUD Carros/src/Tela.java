import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.ScrollPane;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Tela extends JFrame {

	private JPanel contentPane;
	private JTextField tfMarca;	
	private JTextField tfModelo;
	private JTextField tfCor;
	private JTextField tfPlaca;
	private JTextField tfId;
	private JScrollPane jspane; //scrollpane
	protected JTextArea textArea;
	
	

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela frame = new Tela();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
		
		
	}

	public Tela() {
		setTitle("Sistema Gerenciador de Carros");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 499, 340);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbMarca = new JLabel("Marca:");
		lbMarca.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lbMarca.setBounds(21, 22, 46, 14);
		contentPane.add(lbMarca);
		
		tfMarca = new JTextField();
		tfMarca.setBounds(77, 21, 157, 20);
		contentPane.add(tfMarca);
		tfMarca.setColumns(10);
		
		JLabel lbModelo = new JLabel("Modelo:");
		lbModelo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbModelo.setBounds(21, 74, 69, 14);
		contentPane.add(lbModelo);
		
		tfModelo = new JTextField();
		tfModelo.setColumns(10);
		tfModelo.setBounds(77, 73, 157, 20);
		contentPane.add(tfModelo);
		
		JLabel lbCor = new JLabel("Cor:");
		lbCor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbCor.setBounds(21, 130, 46, 14);
		contentPane.add(lbCor);
		
		tfCor = new JTextField();
		tfCor.setBounds(77, 129, 156, 20);
		contentPane.add(tfCor);
		tfCor.setColumns(10);
		
		JLabel lbPlaca = new JLabel("Placa:");
		lbPlaca.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lbPlaca.setBounds(21, 190, 46, 20);
		contentPane.add(lbPlaca);
		
		tfPlaca = new JTextField();
		tfPlaca.setColumns(10);
		tfPlaca.setBounds(78, 192, 156, 20);
		contentPane.add(tfPlaca);
		
		
		//Bot�o de inserir
		JButton btnInserir = new JButton("Inserir");
		btnInserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Carro c= new  Carro();
				CarroDAO dao= new CarroDAO();
				
				//pegando os dados dos campos e setando no objeto Carro
				c.setMarca(tfMarca.getText());
				c.setModelo(tfModelo.getText());
				c.setCor(tfCor.getText());
				c.setPlaca(tfPlaca.getText());
				
				//chamando o CarroDAO e passar o objeto(c) que vamos inserir
				dao.Inserir(c);
				
				
			}
		});
		
		
		
		btnInserir.setBounds(10, 267, 89, 23);
		contentPane.add(btnInserir);
		
		
		
		
		
		
		//Bot�o de Alterar
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
			
				Carro c = new Carro();
				CarroDAO dao= new CarroDAO();
				
				c.setMarca(tfMarca.getText());
				c.setModelo(tfModelo.getText());
				c.setCor(tfCor.getText());
				c.setPlaca(tfPlaca.getText());
				c.setId(Integer.parseInt(tfId.getText()));
				
				dao.alterar(c);
				
				tfMarca.setText("");
				tfModelo.setText("");
				tfCor.setText("");
				tfPlaca.setText("");
				
			}
		});
		
		
		
		
		
		btnAlterar.setBounds(234, 267, 89, 23);
		contentPane.add(btnAlterar);
		
		JLabel lbId = new JLabel("Id:");
		lbId.setBounds(109, 271, 46, 14);
		contentPane.add(lbId);
		
		tfId = new JTextField();
		tfId.setBounds(130, 268, 86, 20);
		contentPane.add(tfId);
		tfId.setColumns(10);
		
		
		
		
		
		//Bot�o de Remover
		JButton btnRemover = new JButton("Remover");
		
		btnRemover.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				Carro c= new Carro();
				CarroDAO dao= new CarroDAO();
				
				c.setId(Integer.parseInt(tfId.getText()));
				
				dao.remover(c);
				
				tfCor.setText("");
			    tfMarca.setText("");
			    tfModelo.setText("");
			    tfPlaca.setText("");
				
				
			}
		});
		
		
		
		
		
		btnRemover.setBounds(361, 267, 89, 23);
		contentPane.add(btnRemover);
		
		
		//text Area
		JTextArea textArea = new JTextArea();
		
		//Jscrollpane:
		//colocando o text area dentro do ScrollPane
		jspane= new JScrollPane(textArea);
		jspane.setBounds(286, 48, 162, 170);
		contentPane.add(jspane);
		
		
		
		textArea.setEditable(false);
		
		listarCarros();
		
		
		}
	
	
	
	
	private void listarCarros() {
		

		CarroDAO dao1 = new CarroDAO();

		Thread thread1 = new Thread(new Runnable() {

			@Override
			public void run() {
				textArea.setText("");
				ArrayList <Carro> carros = dao1.listar();

				for(Carro carro : carros) {
					Carro c= carro;
					
					textArea.append(c + "\n");
					
				}
				try {
					Thread.sleep(20000);
					run();
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}

		});
		thread1.start();

	}

	}

