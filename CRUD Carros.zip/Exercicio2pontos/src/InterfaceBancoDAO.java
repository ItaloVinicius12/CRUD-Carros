import java.util.ArrayList;

public interface InterfaceBancoDAO {
	
        public void Inserir(Carro c);
		public ArrayList<Carro> listar();
		public void remover(Carro c);
		public void alterar(Carro c);

	}



