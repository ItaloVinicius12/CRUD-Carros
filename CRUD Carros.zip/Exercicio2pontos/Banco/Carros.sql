create database Carros;

use Carros;

create table carro(
	
    id int auto_increment not null primary key ,
    marca varchar(30),
    modelo varchar(40),
    cor varchar(20),
    placa varchar(15)
);